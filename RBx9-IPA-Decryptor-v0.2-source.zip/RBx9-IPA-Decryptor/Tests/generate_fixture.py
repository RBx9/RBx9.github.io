import os,struct,hashlib
from pathlib import Path
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import sys
p=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/rbx9_fixture'); p.mkdir(exist_ok=True)
ARM64=0x0100000C
selectors=[[(0,1),(2,3),(4,5),(6,7)],[(2,1),(0,3),(4,7),(6,5)],[(2,0),(4,1),(6,3),(7,5)],[(1,2),(4,0),(7,3),(5,6)]]
rc=(0x68547C2E, 0x7E05E1DE, 0xD495038B, 0x0AB24ADD)
finalsels=[(0,1,2,3),(0,2,4,6),(0,3,5,7),(4,5,6,7)]
fc=(0x5B7198C7,0xEB5DE22C,0x0F8AA8FA,0xF6E1BB3F)
def finish(inp):
    cur=list(inp)
    for sel in selectors:
      out=[]
      for (a,b),c in zip(sel,rc):
        m=cur[a]+cur[b]; square=m*m
        x=(square&0xFFFFFFFF)^(m>>16)^c
        out.extend([x&65535,x>>16])
      cur=out
    out=[]
    for inds,c in zip(finalsels,fc):
       a=(cur[inds[1]]<<16)|cur[inds[0]]
       b=(cur[inds[3]]<<16)|cur[inds[2]]
       m=(a+b)&0xFFFFFFFF;s=m*m;x=(s&0xFFFFFFFF)^(s>>32)^c
       out.extend([x&65535,x>>16])
    return [a^b for a,b in zip(inp,out)]
def xor(a,b): return [i^j for i,j in zip(a,b)]
def aesenc(data,key,iv=None):
    c=Cipher(algorithms.AES(key),modes.CBC(iv) if iv else modes.ECB()).encryptor()
    return c.update(data)+c.finalize()
wrapped=os.urandom(16); work=os.urandom(16); iv=os.urandom(16)
offset=(1<<12).to_bytes(8,'big')
blocks=[wrapped[8:]+offset,wrapped,offset+wrapped[:8]]
a,b,c=(list(struct.unpack('>8H',aesenc(block,work))) for block in blocks)
key=struct.pack('>8H',*finish(xor(finish(xor(finish(a),b)),c)))
credential=os.urandom(16); name=b'test-app'; iviv=os.urandom(16)
clear=bytearray(448);clear[:4]=b'itun';clear[20:24]=b'key ';clear[24:40]=work;clear[44:48]=b'iviv'
sinf_priv=aesenc(bytes(clear),bytes(x^0x30 for x in credential),hashlib.md5(name+iviv).digest())
def atom(t,b):return struct.pack('>I',len(b)+8)+t+b
sinf=atom(b'sinf',atom(b'schi',atom(b'name',name+b'\0')+atom(b'iviv',iviv)+atom(b'priv',sinf_priv)))
page=os.urandom(4096); cipher=aesenc(page,key,iv)
supf=bytes([5])+b'510'+bytes(4)+struct.pack('>I',1)+struct.pack('>III',44,ARM64,0)+struct.pack('>I',1)+wrapped+iv
hdr=struct.pack('<IiiIIIII',0xFEEDFACF,ARM64,0,2,1,24,0,0)
cmd=struct.pack('<IIIIII',0x2C,24,4096,4096,1,0)
original=hdr+cmd+bytes(4096-len(hdr)-len(cmd))+cipher
expected=bytearray(original);expected[4096:]=page;expected[32+16:32+20]=bytes(4)
for name,b in [('encrypted.bin',original),('decrypted.bin',expected),('credential.bin',credential),('sinf.bin',sinf),('supf.bin',supf)]: (p/name).write_bytes(b)
print('fixture ready',len(original),len(sinf),len(supf))
