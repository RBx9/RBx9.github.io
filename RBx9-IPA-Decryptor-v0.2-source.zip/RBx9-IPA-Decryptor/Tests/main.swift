import Foundation
let root = URL(fileURLWithPath:CommandLine.arguments[1])
do {
    let binary = try Data(contentsOf: root.appendingPathComponent("encrypted.bin"))
    let credential = try Data(contentsOf: root.appendingPathComponent("credential.bin"))
    let sinf = try Data(contentsOf: root.appendingPathComponent("sinf.bin"))
    let supf = try Data(contentsOf: root.appendingPathComponent("supf.bin"))
    let expected = try Data(contentsOf: root.appendingPathComponent("decrypted.bin"))
    let (actual, pages) = try FairPlayCore.decryptBinary(binary, sinf:sinf, supf:supf, credential:credential)
    guard actual == expected, pages == 1 else { fatalError("Native port differs from reference") }
    print("PASS: native Swift port matches independently generated FairPlay 1-page fixture")
} catch { fatalError("Fixture error: \(error)") }
