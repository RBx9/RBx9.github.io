#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
cp Tests/AppStoreLinkTests.swift "$tmp/main.swift"
swiftc RBx9Decryptor/AppStoreLookup.swift "$tmp/main.swift" -o "$tmp/testlinks"
"$tmp/testlinks"
