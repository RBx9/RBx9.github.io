import Foundation

func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
    if !condition() { fatalError("FAILED: \(message)") }
}

let inputs: [(String, Int64?, String)] = [
    ("https://apps.apple.com/us/app/example/id123456789", 123456789, "us"),
    ("https://apps.apple.com/sa/app/example/id123456789?uo=4", 123456789, "sa"),
    ("https://apps.apple.com/app/example/id987654321", 987654321, "us"),
    ("https://itunes.apple.com/us/app/example/id123456789", 123456789, "us"),
    ("https://apps.apple.com/us/app/example?id=123456789", 123456789, "us"),
    ("https://evil.example.com/us/app/example/id123456789", nil, "us"),
    ("http://apps.apple.com/us/app/example/id123456789", nil, "us"),
    ("https://apps.apple.com.evil.com/us/app/example/id123456789", nil, "us"),
    ("https://apps.apple.com/us/app/example/idnotanumber", nil, "us")
]
for (url, id, country) in inputs {
    expect(AppStoreLookup.appID(from: url) == id, "app id: \(url)")
    expect(AppStoreLookup.region(from: url) == country, "country: \(url)")
}
print("App Store URL validation passed (\(inputs.count) cases)")
