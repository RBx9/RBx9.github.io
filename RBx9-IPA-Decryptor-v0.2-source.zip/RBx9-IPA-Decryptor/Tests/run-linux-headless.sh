#!/usr/bin/env bash
# Native core regression test against independent Python reference fixture.
# Prerequisites: Swift compiler, clang, OpenSSL libcrypto, Python cryptography package.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
python3 "$SCRIPT_DIR/generate_fixture.py" "$WORK/fixture"
clang -c "$SCRIPT_DIR/crypto_shim.c" -Wno-deprecated-declarations -o "$WORK/crypto_shim.o"
sed '/^import CryptoKit$/d; /^import CommonCrypto$/d' "$ROOT/RBx9Decryptor/FairPlayCore.swift" > "$WORK/NativeCore.swift"
cp "$SCRIPT_DIR/main.swift" "$WORK/main.swift"
swiftc "$SCRIPT_DIR/CryptoShim.swift" "$WORK/NativeCore.swift" "$WORK/main.swift" "$WORK/crypto_shim.o" -lcrypto -o "$WORK/regression"
"$WORK/regression" "$WORK/fixture"
