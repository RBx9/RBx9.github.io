import Foundation
@_silgen_name("fake_md5") func fake_md5(_ data: UnsafeRawPointer?, _ len: Int, _ dest: UnsafeMutableRawPointer?)
@_silgen_name("fake_cccrypt") func fake_cccrypt(_ op:Int32, _ options:Int32, _ key:UnsafeRawPointer?, _ iv:UnsafeRawPointer?, _ src:UnsafeRawPointer?, _ len:Int, _ dest:UnsafeMutableRawPointer?, _ cap:Int, _ moved:inout size_t)->Int32
enum Insecure {
    enum MD5 {
        static func hash(data: Data) -> [UInt8] {
            var digest = [UInt8](repeating: 0, count: 16)
            data.withUnsafeBytes { src in digest.withUnsafeMutableBytes { out in fake_md5(src.baseAddress, data.count, out.baseAddress) } }
            return digest
        }
    }
}
typealias CCCryptorStatus = Int32
typealias CCOperation = Int32
typealias CCAlgorithm = Int32
typealias CCOptions = Int32
let kCCBlockSizeAES128 = 16
let kCCKeySizeAES128 = 16
let kCCDecrypt: Int32 = 1
let kCCEncrypt: Int32 = 0
let kCCAlgorithmAES: Int32 = 0
let kCCOptionECBMode: Int32 = 2
let kCCSuccess: Int32 = 0
func CCCrypt(_ op:CCOperation,_ alg:CCAlgorithm,_ opts:CCOptions,_ key:UnsafeRawPointer?,_ keylength:Int,_ iv:UnsafeRawPointer?,_ input:UnsafeRawPointer?,_ inputlength:Int,_ dest:UnsafeMutableRawPointer?,_ capacity:Int,_ moved:inout size_t)->CCCryptorStatus {
    fake_cccrypt(op,opts,key,iv,input,inputlength,dest,capacity,&moved)
}
