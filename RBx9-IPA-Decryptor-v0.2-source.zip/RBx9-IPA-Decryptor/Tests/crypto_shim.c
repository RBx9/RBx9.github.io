#include <openssl/evp.h>
#include <openssl/md5.h>
#include <stddef.h>
int fake_cccrypt(int operation, int options, const void *key, const void *iv, const void *src, size_t len, void *out, size_t cap, size_t *moved) {
    if (cap < len) return -1;
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return -2;
    const EVP_CIPHER *cipher = (options & 2) ? EVP_aes_128_ecb() : EVP_aes_128_cbc();
    if (EVP_CipherInit_ex(ctx, cipher, NULL, key, iv, operation == 1 ? 0 : 1) != 1) { EVP_CIPHER_CTX_free(ctx); return -3; }
    if (EVP_CIPHER_CTX_set_padding(ctx, 0) != 1) { EVP_CIPHER_CTX_free(ctx); return -4; }
    int got = 0, finalgot = 0;
    if (EVP_CipherUpdate(ctx, out, &got, src, (int)len) != 1) { EVP_CIPHER_CTX_free(ctx); return -5; }
    if (EVP_CipherFinal_ex(ctx, (unsigned char*)out + got, &finalgot) != 1) { EVP_CIPHER_CTX_free(ctx); return -6; }
    *moved = (size_t)(got + finalgot);
    EVP_CIPHER_CTX_free(ctx);
    return 0;
}
void fake_md5(const void *data, size_t len, unsigned char *dest) { MD5(data, len, dest); }
