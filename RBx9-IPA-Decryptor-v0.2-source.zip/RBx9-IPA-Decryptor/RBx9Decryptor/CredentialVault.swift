// SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Security

enum CredentialVault {
    private static let service = "com.rbx9.ipadecryptor.credential"
    private static let account = "fairplay-v1"

    static func save(_ credential: Data) throws {
        guard credential.count == 16 else { throw DecryptFailure("credential.bin must be exactly 16 bytes") }
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
        var params = query
        params[kSecValueData as String] = credential
        params[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let status = SecItemAdd(params as CFDictionary, nil)
        guard status == errSecSuccess else { throw DecryptFailure("Keychain save failed: \(status)") }
    }

    static func load() throws -> Data? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let credential = result as? Data, credential.count == 16 else {
            throw DecryptFailure("Cannot read Keychain credential: \(status)")
        }
        return credential
    }

    static func delete() {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
    }
}
