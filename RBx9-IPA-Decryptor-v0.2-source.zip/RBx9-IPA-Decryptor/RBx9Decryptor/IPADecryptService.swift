// SPDX-License-Identifier: GPL-3.0-only
import Foundation
import ZIPFoundation

struct DecryptReport {
    let outputURL: URL
    let binaries: Int
    let pages: Int
}

struct IPADecryptService {
    private let fs = FileManager.default

    func run(ipaURL: URL, credential: Data, onProgress: @escaping (String, Double) -> Void) throws -> DecryptReport {
        guard credential.count == 16 else { throw DecryptFailure("Import a valid 16-byte credential.bin first") }
        let temp = fs.temporaryDirectory.appendingPathComponent("RBx9-\(UUID().uuidString)", isDirectory: true)
        let extracted = temp.appendingPathComponent("extracted", isDirectory: true)
        try fs.createDirectory(at: extracted, withIntermediateDirectories: true)
        defer { try? fs.removeItem(at: temp) }

        onProgress("Unpacking IPA…", 0.04)
        try fs.unzipItem(at: ipaURL, to: extracted)
        guard fs.fileExists(atPath: extracted.appendingPathComponent("Payload").path) else {
            throw DecryptFailure("Not a valid IPA: Payload folder is missing")
        }
        let files = try allFiles(at: extracted)
        let fileSet = Set(files.map { $0.relative })
        let supfs = files.filter { $0.relative.hasSuffix(".supf") }
            .sorted { $0.relative < $1.relative }
        let preferred = Dictionary(grouping: supfs, by: { $0.relative.replacingOccurrences(of: ".v5.supf", with: "")
                                                    .replacingOccurrences(of: ".supf", with: "") })
        let chosen = preferred.values.compactMap { group in
            group.first(where: { $0.relative.hasSuffix(".v5.supf") }) ?? group.first
        }.sorted { $0.relative < $1.relative }

        guard !chosen.isEmpty else {
            throw DecryptFailure("No SINF/SUPF license metadata found in IPA")
        }
        var targets: [(binary: String, sinf: String, supf: String)] = []
        for info in chosen {
            guard let range = info.relative.range(of: "/SC_Info/", options: .backwards) else { continue }
            let bundle = String(info.relative[..<range.lowerBound])
            let filename = String(info.relative[range.upperBound...])
            let v5 = filename.hasSuffix(".v5.supf")
            let stem = String(filename.dropLast(v5 ? ".v5.supf".count : ".supf".count))
            let binary = bundle + "/" + stem
            guard fileSet.contains(binary) else { throw DecryptFailure("Missing encrypted binary: \(binary)") }
            let candidate = bundle + "/SC_Info/" + stem + (v5 ? ".v4.sinf" : ".sinf")
            let fallback = bundle + "/SC_Info/" + stem + ".sinf"
            let sinf = fileSet.contains(candidate) ? candidate : (fileSet.contains(fallback) ? fallback : enclosingSINF(bundle: bundle, files: fileSet))
            guard let sinf else { throw DecryptFailure("Missing SINF license for \(binary)") }
            targets.append((binary, sinf, info.relative))
        }
        guard !targets.isEmpty else { throw DecryptFailure("No decryption candidates found") }

        var processed = 0
        var pages = 0
        for (index, target) in targets.enumerated() {
            let bin = extracted.appendingPathComponent(target.binary)
            let binary = try Data(contentsOf: bin, options: .mappedIfSafe)
            let encrypted: Bool
            do {
                encrypted = try !FairPlayCore.encryptionInfo(binary).isEmpty
            } catch {
                throw DecryptFailure("Unsupported binary \(target.binary): \(error.localizedDescription)")
            }
            if !encrypted { continue }
            onProgress("Decrypting \(target.binary.components(separatedBy: "/").last ?? "binary")", 0.10 + Double(index) / Double(targets.count) * 0.78)
            let sinf = try Data(contentsOf: extracted.appendingPathComponent(target.sinf))
            let supf = try Data(contentsOf: extracted.appendingPathComponent(target.supf))
            let (clear, count) = try FairPlayCore.decryptBinary(binary, sinf: sinf, supf: supf, credential: credential) { done, total in
                let part = Double(done) / Double(max(total,1))
                onProgress("Decrypting pages: \(done)/\(total)", 0.10 + (Double(index) + part)/Double(targets.count) * 0.78)
            }
            try clear.write(to: bin, options: .atomic)
            pages += count
            processed += 1
        }
        guard processed > 0 else { throw DecryptFailure("No encrypted arm64 Mach-O pages found; IPA may already be decrypted") }

        onProgress("Packing decrypted IPA…", 0.90)
        let folder = fs.urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent("Decrypted", isDirectory: true)
        try fs.createDirectory(at: folder, withIntermediateDirectories: true)
        let base = ipaURL.deletingPathExtension().lastPathComponent
        let output = folder.appendingPathComponent("\(base)-decrypted-\(UUID().uuidString.prefix(6)).ipa")
        try fs.zipItem(at: extracted, to: output, shouldKeepParent: false, compressionMethod: .deflate)
        onProgress("Complete", 1.0)
        return DecryptReport(outputURL: output, binaries: processed, pages: pages)
    }

    private func enclosingSINF(bundle: String, files: Set<String>) -> String? {
        var parts = bundle.split(separator: "/").map(String.init)
        while !parts.isEmpty {
            let prefix = parts.joined(separator: "/")
            if prefix.hasSuffix(".app") {
                let directory = prefix + "/SC_Info/"
                let matches = files.filter { $0.hasPrefix(directory) && $0.hasSuffix(".sinf") && !$0.dropFirst(directory.count).contains("/") }.sorted()
                if let first = matches.first { return first }
            }
            parts.removeLast()
        }
        return nil
    }

    private func allFiles(at root: URL) throws -> [(relative: String, url: URL)] {
        guard let enumerator = fs.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey], options: [.skipsHiddenFiles]) else {
            throw DecryptFailure("Cannot inspect extracted IPA")
        }
        var found: [(String,URL)] = []
        for case let url as URL in enumerator {
            let flags = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
            guard flags.isRegularFile == true, flags.isSymbolicLink != true else { continue }
            let relative = String(url.path.dropFirst(root.path.count + 1))
            found.append((relative, url))
        }
        return found
    }
}
