// SPDX-License-Identifier: GPL-3.0-only
// App Store catalog metadata only. This API does NOT provide an IPA download URL.
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct AppStoreListing: Decodable, Identifiable {
    let trackId: Int64
    let trackName: String
    let bundleId: String
    let version: String?
    let sellerName: String?
    let artworkUrl100: URL?
    let trackViewUrl: URL?
    var id: Int64 { trackId }
}

struct AppStoreResponse: Decodable {
    let resultCount: Int
    let results: [AppStoreListing]
}

enum AppStoreLookupError: LocalizedError {
    case invalidLink
    case lookupFailed
    case notAvailable
    case invalidResponse
    var errorDescription: String? {
        switch self {
        case .invalidLink:
            return "Paste a valid apps.apple.com App Store link. An App Store link is not a direct IPA download."
        case .lookupFailed:
            return "Could not connect to the App Store catalog. Check your connection and try again."
        case .notAvailable:
            return "This app is not listed in the selected App Store region. The link may be unavailable or removed."
        case .invalidResponse:
            return "The App Store catalog returned invalid app information."
        }
    }
}

struct AppStoreLookup {
    static func appID(from text: String) -> Int64? {
        guard let url = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme?.lowercased() == "https", let host = url.host?.lowercased(),
              host == "apps.apple.com" || host == "itunes.apple.com" else { return nil }
        // Examples: https://apps.apple.com/us/app/example/id123456789 or ?id=123456789
        let pattern = #"(?:^|/)id([0-9]{6,})(?:/|$)"#
        if let re = try? NSRegularExpression(pattern: pattern),
           let match = re.firstMatch(in: url.path, range: NSRange(url.path.startIndex..., in: url.path)),
           let r = Range(match.range(at: 1), in: url.path) {
            return Int64(url.path[r])
        }
        if let id = URLComponents(url: url, resolvingAgainstBaseURL: false)?
            .queryItems?.first(where: { $0.name.lowercased() == "id" })?.value,
           id.count >= 6, id.allSatisfy(\.isNumber) { return Int64(id) }
        return nil
    }

    static func region(from text: String) -> String {
        guard let url = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)) else { return "us" }
        let first = url.pathComponents.dropFirst().first ?? "us"
        let region = first.lowercased()
        return region.range(of: #"^[a-z]{2}$"#, options: .regularExpression) != nil ? region : "us"
    }

    static func lookup(_ text: String, session: URLSession = .shared) async throws -> AppStoreListing {
        guard let id = appID(from: text) else { throw AppStoreLookupError.invalidLink }
        var components = URLComponents()
        components.scheme = "https"
        components.host = "itunes.apple.com"
        components.path = "/lookup"
        components.queryItems = [URLQueryItem(name: "id", value: String(id)),
                                 URLQueryItem(name: "country", value: region(from: text)),
                                 URLQueryItem(name: "entity", value: "software")]
        guard let url = components.url else { throw AppStoreLookupError.invalidLink }
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response): (Data, URLResponse)
        do { (data, response) = try await session.data(for: req) }
        catch { throw AppStoreLookupError.lookupFailed }
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else { throw AppStoreLookupError.lookupFailed }
        guard data.count < 2_000_000, let info = try? JSONDecoder().decode(AppStoreResponse.self, from: data) else {
            throw AppStoreLookupError.invalidResponse
        }
        guard let app = info.results.first(where: { $0.trackId == id }) else { throw AppStoreLookupError.notAvailable }
        return app
    }
}
