// SPDX-License-Identifier: GPL-3.0-only
import SwiftUI

@main
struct RBx9App: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
