// SPDX-License-Identifier: GPL-3.0-only
// Native Swift port of key derivation and Mach-O handling inspired by
// https://github.com/EthanArbuckle/fairplay-decrypt (GPL-3.0).
// Review and test against upstream's licensed fixtures before production use.
import Foundation
import CryptoKit
import CommonCrypto

struct DecryptFailure: LocalizedError {
    let reason: String
    init(_ reason: String) { self.reason = reason }
    var errorDescription: String? { reason }
}

private struct Bytes {
    let value: Data
    init(_ value: Data) { self.value = value }
    func check(_ offset: Int, _ size: Int) throws {
        guard offset >= 0, size >= 0, offset <= value.count, size <= value.count - offset else {
            throw DecryptFailure("Malformed input: unexpected end of binary")
        }
    }
    func data(_ offset: Int, _ length: Int) throws -> Data {
        try check(offset, length)
        return value.subdata(in: offset..<(offset + length))
    }
    func u32(_ offset: Int, little: Bool = true) throws -> UInt32 {
        try check(offset, 4)
        let x = value[offset..<(offset+4)]
        return little ? x.enumerated().reduce(UInt32(0)) { $0 | (UInt32($1.element) << ($1.offset * 8)) }
                      : x.reduce(UInt32(0)) { ($0 << 8) | UInt32($1) }
    }
    func u64(_ offset: Int, little: Bool = true) throws -> UInt64 {
        try check(offset, 8)
        let x = value[offset..<(offset+8)]
        return little ? x.enumerated().reduce(UInt64(0)) { $0 | (UInt64($1.element) << ($1.offset * 8)) }
                      : x.reduce(UInt64(0)) { ($0 << 8) | UInt64($1) }
    }
    func u16(_ offset: Int) throws -> UInt16 {
        try check(offset, 2)
        return (UInt16(value[offset]) << 8) | UInt16(value[offset + 1])
    }
}

struct MachoEncryptionInfo {
    let base: Int
    let cryptOffset: Int
    let cryptSize: Int
    let cryptIDOffset: Int
    let subtype: UInt32
}

enum FairPlayCore {
    private static let arm64: UInt32 = 0x0100000C
    private static let pageSize = 4096
    private static let roundSelectors: [[(Int, Int)]] = [
        [(0,1),(2,3),(4,5),(6,7)],
        [(2,1),(0,3),(4,7),(6,5)],
        [(2,0),(4,1),(6,3),(7,5)],
        [(1,2),(4,0),(7,3),(5,6)]
    ]
    private static let roundConstants: [UInt32] = [0x68547C2E, 0x7E05E1DE, 0xD495038B, 0x0AB24ADD]
    private static let finalSelectors: [[Int]] = [[0,1,2,3], [0,2,4,6], [0,3,5,7], [4,5,6,7]]
    private static let finalConstants: [UInt32] = [0x5B7198C7, 0xEB5DE22C, 0x0F8AA8FA, 0xF6E1BB3F]

    static func encryptionInfo(_ data: Data) throws -> [MachoEncryptionInfo] {
        let b = Bytes(data)
        guard data.count >= 4 else { throw DecryptFailure("Not a Mach-O executable") }
        let magic = try b.data(0,4)
        var arches: [(base: Int, size: Int, sub: UInt32)] = []
        if magic == Data([0xCA,0xFE,0xBA,0xBE]) || magic == Data([0xCA,0xFE,0xBA,0xBF]) {
            let fat64 = (magic[3] == 0xBF)
            let count = Int(try b.u32(4, little: false))
            let stride = fat64 ? 32 : 20
            guard count > 0, count <= 16 else { throw DecryptFailure("Invalid Mach-O architecture count") }
            try b.check(8, count * stride)
            for i in 0..<count {
                let off = 8 + i * stride
                if try b.u32(off, little: false) != arm64 { continue }
                let sub = try b.u32(off+4, little: false)
                let base = try fat64 ? Int(exactly: b.u64(off+8, little: false)) : Int(b.u32(off+8, little: false))
                let size = try fat64 ? Int(exactly: b.u64(off+16, little: false)) : Int(b.u32(off+12, little: false))
                guard let base, let size else { throw DecryptFailure("Oversized Mach-O architecture") }
                arches.append((base, size, sub))
            }
        } else if magic == Data([0xCF,0xFA,0xED,0xFE]) {
            arches = [(0, data.count, try b.u32(8))]
        } else {
            throw DecryptFailure("Not a supported arm64 Mach-O")
        }
        guard !arches.isEmpty else { throw DecryptFailure("No arm64 slice found") }
        var found: [MachoEncryptionInfo] = []
        for arch in arches {
            try b.check(arch.base, arch.size)
            try b.check(arch.base, 32)
            guard try b.u32(arch.base) == 0xFEEDFACF,
                  try b.u32(arch.base + 4) == arm64 else { throw DecryptFailure("Invalid arm64 Mach-O header") }
            let ncmds = Int(try b.u32(arch.base + 16))
            let sizeofcmds = Int(try b.u32(arch.base + 20))
            guard ncmds <= 1000, sizeofcmds <= arch.size - 32 else { throw DecryptFailure("Malformed load commands") }
            var pos = arch.base + 32
            let commandsEnd = pos + sizeofcmds
            var encrypted: MachoEncryptionInfo?
            for _ in 0..<ncmds {
                try b.check(pos,8)
                let cmd = try b.u32(pos)
                let commandSize = Int(try b.u32(pos+4))
                guard commandSize >= 8, commandSize <= commandsEnd - pos else { throw DecryptFailure("Invalid Mach-O load command") }
                if cmd == 0x2C {
                    guard encrypted == nil, commandSize >= 24 else { throw DecryptFailure("Unexpected encryption command") }
                    let cryptOff = Int(try b.u32(pos+8))
                    let cryptSize = Int(try b.u32(pos+12))
                    let cryptID = try b.u32(pos+16)
                    if cryptID != 0 {
                        guard cryptID == 1, cryptSize > 0, cryptSize % pageSize == 0,
                              cryptOff <= arch.size, cryptSize <= arch.size - cryptOff,
                              pos + 16 < arch.base + cryptOff else {
                            throw DecryptFailure("Unsupported cryptid or encrypted bounds")
                        }
                        encrypted = MachoEncryptionInfo(base: arch.base, cryptOffset: cryptOff,
                          cryptSize: cryptSize, cryptIDOffset: pos+16, subtype: arch.sub)
                    }
                }
                pos += commandSize
            }
            guard pos == commandsEnd else { throw DecryptFailure("Mach-O load command size mismatch") }
            if let encrypted { found.append(encrypted) }
        }
        return found
    }

    private static func atoms(_ data: Data, _ start: Int, _ end: Int) throws -> [(String, Int, Int)] {
        let b = Bytes(data)
        guard start >= 0, end <= data.count, start <= end else { throw DecryptFailure("Bad SINF atom region") }
        var result: [(String,Int,Int)] = []
        var pos = start
        while pos < end {
            try b.check(pos,8)
            let size = Int(try b.u32(pos, little: false))
            guard size >= 8, size <= end - pos else { throw DecryptFailure("Bad SINF atom length") }
            let name = String(data: try b.data(pos+4,4), encoding: .ascii) ?? "????"
            result.append((name, pos+8, pos+size))
            pos += size
        }
        return result
    }

    private static func sinfField(_ sinf: Data, _ key: String) throws -> Data {
        let roots = try atoms(sinf, 0, sinf.count)
        guard roots.count == 1, roots[0].0 == "sinf" else { throw DecryptFailure("Missing SINF root") }
        let schis = try atoms(sinf, roots[0].1, roots[0].2).filter { $0.0 == "schi" }
        guard schis.count == 1 else { throw DecryptFailure("Missing SINF schi") }
        let fields = try atoms(sinf, schis[0].1, schis[0].2).filter { $0.0 == key }
        guard fields.count == 1 else { throw DecryptFailure("Missing SINF field \(key)") }
        return try Bytes(sinf).data(fields[0].1, fields[0].2 - fields[0].1)
    }

    private static func aes(_ input: Data, key: Data, iv: Data? = nil, decrypt: Bool = false) throws -> Data {
        guard key.count == 16, input.count % 16 == 0, iv == nil || iv?.count == 16 else {
            throw DecryptFailure("Invalid AES block/key/IV length")
        }
        var output = Data(count: input.count + kCCBlockSizeAES128)
        var moved: size_t = 0
        let outputCapacity = output.count
        let status: CCCryptorStatus = input.withUnsafeBytes { source in
            key.withUnsafeBytes { keyBytes in
                output.withUnsafeMutableBytes { dest in
                    if let iv {
                        return iv.withUnsafeBytes { ivBytes in
                            CCCrypt(decrypt ? CCOperation(kCCDecrypt) : CCOperation(kCCEncrypt),
                                    CCAlgorithm(kCCAlgorithmAES), CCOptions(0),
                                    keyBytes.baseAddress, kCCKeySizeAES128, ivBytes.baseAddress,
                                    source.baseAddress, input.count, dest.baseAddress, outputCapacity, &moved)
                        }
                    }
                    return CCCrypt(decrypt ? CCOperation(kCCDecrypt) : CCOperation(kCCEncrypt),
                                   CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionECBMode),
                                   keyBytes.baseAddress, kCCKeySizeAES128, nil,
                                   source.baseAddress, input.count, dest.baseAddress, outputCapacity, &moved)
                }
            }
        }
        guard status == kCCSuccess, moved == input.count else { throw DecryptFailure("AES operation failed: \(status)") }
        return output.prefix(moved)
    }

    private static func workKey(_ credential: Data, sinf: Data) throws -> Data {
        guard credential.count == 16 else { throw DecryptFailure("credential.bin must contain exactly 16 bytes") }
        let name = Data(try sinfField(sinf, "name").prefix { $0 != 0 })
        let iviv = try sinfField(sinf, "iviv")
        var priv = try sinfField(sinf, "priv")
        guard priv.count == 440 || priv.count == 448, iviv.count == 16 else { throw DecryptFailure("Unsupported SINF priv/iviv record") }
        if priv.count == 440 {
            guard priv.suffix(8).allSatisfy({ $0 == 0 }) else { throw DecryptFailure("Bad SINF priv trailer") }
            priv = priv.prefix(priv.count - 8)
        }
        let iv = Data(Insecure.MD5.hash(data: name + iviv))
        let key = Data(zip(credential, Data(repeating: 0x30, count: 16)).map { $0 ^ $1 })
        let clear = try aes(priv, key: key, iv: iv, decrypt: true)
        guard clear.count >= 48, clear.prefix(4) == Data("itun".utf8),
              clear.subdata(in:20..<24) == Data("key ".utf8),
              clear.subdata(in:44..<48) == Data("iviv".utf8) else {
            throw DecryptFailure("Credential cannot decrypt SINF; check Apple account ownership")
        }
        return clear.subdata(in: 24..<40)
    }

    private static func supfOffset(_ supf: Data, pages: Int, subtype: UInt32) throws -> Int {
        guard supf.count >= 12, [3,5].contains(supf[0]),
          ["507","510","612"].contains(String(data: supf.subdata(in: 1..<4), encoding: .ascii) ?? "") else {
            throw DecryptFailure("Unsupported SUPF format")
        }
        let headerSize = (supf[0] == 3 ? 32 : 12)
        let b = Bytes(supf)
        let count = Int(try b.u32(8, little: false))
        guard count > 0, count <= 16 else { throw DecryptFailure("Bad SUPF architecture count") }
        var pos = 12
        for _ in 0..<count {
            try b.check(pos,4 + headerSize)
            let length = Int(try b.u32(pos, little: false))
            let cpu = try b.u32(pos+4, little: false)
            let sub = try b.u32(pos+8, little: false)
            guard length >= headerSize, length <= supf.count - pos - 4 else { throw DecryptFailure("Bad SUPF architecture size") }
            let countPages = Int(try b.u32(pos + headerSize, little: false))
            if cpu == arm64 && sub == subtype {
                guard countPages >= pages, pages <= (length - headerSize)/32 else { throw DecryptFailure("Incomplete SUPF page records") }
                return pos + 4 + headerSize
            }
            pos += 4 + length
        }
        throw DecryptFailure("SUPF arm64 subtype not found")
    }

    private static func finish(_ input: [UInt16]) -> [UInt16] {
        var current = input
        for selectors in roundSelectors {
            var next: [UInt16] = []
            for (index, pair) in selectors.enumerated() {
                let mixed = UInt64(current[pair.0]) + UInt64(current[pair.1])
                let square = mixed * mixed
                let x = UInt32(truncatingIfNeeded: square) ^ UInt32(mixed >> 16) ^ roundConstants[index]
                next.append(UInt16(truncatingIfNeeded: x))
                next.append(UInt16(truncatingIfNeeded: x >> 16))
            }
            current = next
        }
        var result: [UInt16] = []
        for (index, indices) in finalSelectors.enumerated() {
            let a = (UInt32(current[indices[1]]) << 16) | UInt32(current[indices[0]])
            let b = (UInt32(current[indices[3]]) << 16) | UInt32(current[indices[2]])
            let mixed = a &+ b
            let square = UInt64(mixed) * UInt64(mixed)
            let x = UInt32(truncatingIfNeeded: square) ^ UInt32(truncatingIfNeeded: square >> 32) ^ finalConstants[index]
            result.append(UInt16(truncatingIfNeeded: x))
            result.append(UInt16(truncatingIfNeeded: x >> 16))
        }
        return zip(input, result).map { $0 ^ $1 }
    }

    private static func xor(_ a: [UInt16], _ b: [UInt16]) -> [UInt16] {
        zip(a,b).map { $0 ^ $1 }
    }

    private static func words(_ data: Data) throws -> [UInt16] {
        guard data.count == 16 else { throw DecryptFailure("Expected 16-byte block") }
        return try (0..<8).map { try Bytes(data).u16($0*2) }
    }

    private static func pageKey(_ wrapped: Data, pageIndex: Int, work: Data) throws -> Data {
        guard wrapped.count == 16, pageIndex >= 0, pageIndex < (1 << 32) else { throw DecryptFailure("Invalid page key input") }
        let be = UInt64(pageIndex) << 12
        let pageOffset = Data((0..<8).map { UInt8(truncatingIfNeeded: be >> (56 - $0 * 8)) })
        let first = wrapped.suffix(8) + pageOffset
        let second = wrapped
        let third = pageOffset + wrapped.prefix(8)
        let a = try words(aes(first, key: work))
        let b = try words(aes(second, key: work))
        let c = try words(aes(third, key: work))
        let final = finish(xor(finish(xor(finish(a), b)), c))
        var result = Data()
        for word in final {
            result.append(UInt8(truncatingIfNeeded: word >> 8))
            result.append(UInt8(truncatingIfNeeded: word))
        }
        return result
    }

    static func decryptBinary(_ binary: Data, sinf: Data, supf: Data, credential: Data,
                              progress: ((Int, Int) -> Void)? = nil) throws -> (Data, Int) {
        let infos = try encryptionInfo(binary)
        guard !infos.isEmpty else { throw DecryptFailure("Binary has no encrypted arm64 pages") }
        let work = try workKey(credential, sinf: sinf)
        var output = binary
        let total = infos.reduce(0) { $0 + $1.cryptSize / pageSize }
        var completed = 0
        for info in infos {
            let pages = info.cryptSize / pageSize
            let recordBase = try supfOffset(supf, pages: pages, subtype: info.subtype)
            for local in 0..<pages {
                let rec = try Bytes(supf).data(recordBase + local*32, 32)
                let index = (info.base + info.cryptOffset) / pageSize + local
                let key = try pageKey(rec.prefix(16), pageIndex: index, work: work)
                let start = info.base + info.cryptOffset + local * pageSize
                let ciphertext = try Bytes(binary).data(start, pageSize)
                let plaintext = try aes(ciphertext, key: key, iv: rec.suffix(16), decrypt: true)
                output.replaceSubrange(start..<(start + pageSize), with: plaintext)
                completed += 1
                if completed % 16 == 0 || completed == total { progress?(completed, total) }
            }
            output.replaceSubrange(info.cryptIDOffset..<(info.cryptIDOffset+4), with: Data(repeating: 0, count: 4))
        }
        guard try encryptionInfo(output).isEmpty else { throw DecryptFailure("Post-decryption verification failed") }
        return (output, total)
    }
}
