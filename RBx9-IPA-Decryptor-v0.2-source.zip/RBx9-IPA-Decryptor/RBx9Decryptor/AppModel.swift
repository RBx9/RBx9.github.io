// SPDX-License-Identifier: GPL-3.0-only
import Foundation
import SwiftUI

@MainActor
final class AppModel: ObservableObject {
    @Published var credentialAvailable = false
    @Published var storeApp: AppStoreListing?
    @Published var storeURL = ""
    @Published var lookingUpApp = false
    @Published var importedBundleID: String?
    @Published var importedIPA: URL?
    @Published var outputIPA: URL?
    @Published var error: String?
    @Published var status = "Ready"
    @Published var progress = 0.0
    @Published var running = false
    @Published var report = ""

    init() {
        do { credentialAvailable = try CredentialVault.load() != nil }
        catch { self.error = error.localizedDescription }
    }

    func resolveStoreLink(_ text: String) {
        guard !lookingUpApp else { return }
        guard AppStoreLookup.appID(from: text) != nil else {
            error = AppStoreLookupError.invalidLink.localizedDescription
            return
        }
        storeURL = text
        storeApp = nil
        importedIPA = nil
        importedBundleID = nil
        outputIPA = nil
        lookingUpApp = true
        status = "Looking up App Store listing…"
        Task {
            do {
                let listing = try await AppStoreLookup.lookup(text)
                self.storeApp = listing
                self.status = "App found. Import a licensed IPA for \(listing.trackName)."
            } catch {
                self.error = error.localizedDescription
                self.status = "App lookup failed"
            }
            self.lookingUpApp = false
        }
    }

    func importCredential(_ url: URL) {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let credential = try Data(contentsOf: url)
            try CredentialVault.save(credential)
            credentialAvailable = true
            error = nil
            status = "Credential stored securely"
        } catch { self.error = error.localizedDescription }
    }

    func removeCredential() {
        CredentialVault.delete()
        credentialAvailable = false
        status = "Credential removed"
    }

    func importIPA(_ url: URL) {
        guard url.pathExtension.lowercased() == "ipa" else { error = "Select an .ipa file"; return }
        status = "Checking IPA…"
        outputIPA = nil
        let expectedBundle = storeApp?.bundleId
        Task.detached(priority: .userInitiated) { [weak self] in
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            do {
                let actualBundle = try IPAIdentity.bundleIdentifier(in: url)
                if let expectedBundle, expectedBundle != actualBundle {
                    throw DecryptFailure("IPA bundle ID \(actualBundle) does not match the App Store listing (\(expectedBundle)). Select the correct IPA.")
                }
                let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                    .appendingPathComponent("Imports", isDirectory: true)
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let dest = folder.appendingPathComponent("\(UUID().uuidString)-\(url.lastPathComponent)")
                try FileManager.default.copyItem(at: url, to: dest)
                await MainActor.run {
                    self?.importedIPA = dest
                    self?.importedBundleID = actualBundle
                    self?.error = nil
                    self?.status = "IPA imported"
                }
            } catch {
                await MainActor.run { self?.error = "IPA import failed: \(error.localizedDescription)" }
            }
        }
    }

    func decrypt() {
        guard !running, let ipaURL = importedIPA else { return }
        let credential: Data
        do {
            guard let stored = try CredentialVault.load() else { throw DecryptFailure("Import credential.bin first") }
            credential = stored
        } catch { self.error = error.localizedDescription; return }
        running = true
        outputIPA = nil
        error = nil
        progress = 0
        report = ""
        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                let result = try IPADecryptService().run(ipaURL: ipaURL, credential: credential) { stage, percent in
                    Task { @MainActor [weak self] in
                        self?.status = stage
                        self?.progress = percent
                    }
                }
                await MainActor.run {
                    self?.outputIPA = result.outputURL
                    self?.progress = 1
                    self?.running = false
                    self?.status = "Decryption completed"
                    self?.report = "\(result.binaries) binaries • \(result.pages) pages"
                }
            } catch {
                await MainActor.run {
                    self?.error = error.localizedDescription
                    self?.status = "Decryption failed"
                    self?.running = false
                }
            }
        }
    }
}
