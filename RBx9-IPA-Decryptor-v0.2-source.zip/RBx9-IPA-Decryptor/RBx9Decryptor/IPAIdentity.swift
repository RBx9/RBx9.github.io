// SPDX-License-Identifier: GPL-3.0-only
import Foundation
import ZIPFoundation

struct IPAIdentity {
    static func bundleIdentifier(in ipaURL: URL) throws -> String {
        let archive = try Archive(url: ipaURL, accessMode: .read)
        // Only the top-level .app is checked; extensions and frameworks have separate identifiers.
        guard let plistEntry = archive.first(where: { entry in
            let parts = entry.path.split(separator: "/")
            return parts.count == 3 && parts[0] == "Payload" && parts[1].hasSuffix(".app") && parts[2] == "Info.plist"
        }) else { throw DecryptFailure("IPA has no top-level Payload/*.app/Info.plist") }
        guard plistEntry.uncompressedSize < 2_000_000 else { throw DecryptFailure("IPA Info.plist is unusually large") }
        var data = Data()
        _ = try archive.extract(plistEntry, consumer: { part in
            guard data.count + part.count <= 2_000_000 else { throw DecryptFailure("IPA Info.plist exceeds size limit") }
            data.append(part)
        })
        guard let plist = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
              let bundle = plist["CFBundleIdentifier"] as? String, !bundle.isEmpty else {
            throw DecryptFailure("IPA Info.plist is missing a bundle identifier")
        }
        return bundle
    }
}
