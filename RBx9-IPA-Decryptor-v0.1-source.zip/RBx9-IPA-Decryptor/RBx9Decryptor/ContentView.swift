// SPDX-License-Identifier: GPL-3.0-only
import SwiftUI
import UniformTypeIdentifiers

private struct StepCard<Content: View>: View {
    let number: String
    let heading: String
    let subtitle: String
    let content: Content

    init(number: String, heading: String, subtitle: String, @ViewBuilder content: () -> Content) {
        self.number = number
        self.heading = heading
        self.subtitle = subtitle
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack(alignment: .top, spacing: 12) {
                Text(number).font(.system(size: 15, weight: .heavy, design: .rounded))
                    .foregroundStyle(.cyan).frame(width: 32, height: 32)
                    .background(.cyan.opacity(0.13), in: RoundedRectangle(cornerRadius: 10))
                VStack(alignment: .leading, spacing: 3) {
                    Text(heading).font(.headline)
                    Text(subtitle).font(.caption).foregroundStyle(.secondary)
                }
            }
            content
        }
        .padding(18)
        .background(Color(red:0.09, green:0.14, blue:0.22), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius:22).stroke(.white.opacity(0.06)))
    }
}

struct ContentView: View {
    @StateObject private var model = AppModel()
    @State private var pickingCredential = false
    @State private var pickingIPA = false
    @State private var confirmingCredentialRemoval = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red:0.035,green:0.06,blue:0.10).ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 17) {
                        header
                        StepCard(number:"01", heading:"FairPlay Credential", subtitle:"16-byte credential from an account that owns the IPA") {
                            HStack {
                                Image(systemName: model.credentialAvailable ? "checkmark.shield.fill" : "lock.shield")
                                    .foregroundStyle(model.credentialAvailable ? Color.green : Color.orange)
                                Text(model.credentialAvailable ? "Stored in iOS Keychain" : "No credential imported")
                                    .font(.subheadline)
                                Spacer()
                            }
                            Button("Import credential.bin") { pickingCredential = true }
                                .buttonStyle(RBx9ButtonStyle())
                            if model.credentialAvailable {
                                Button("Remove saved credential", role: .destructive) { confirmingCredentialRemoval = true }
                                    .font(.caption).padding(.top, 3)
                            }
                        }
                        StepCard(number:"02", heading:"Encrypted IPA", subtitle:"Choose an App Store IPA from the Files app") {
                            if let ipa = model.importedIPA {
                                Label(ipa.lastPathComponent, systemImage:"shippingbox.fill")
                                    .font(.footnote).lineLimit(2)
                                    .foregroundStyle(.white.opacity(0.9))
                            }
                            Button("Choose IPA") { pickingIPA = true }.buttonStyle(RBx9ButtonStyle())
                        }
                        StepCard(number:"03", heading:"Decrypt & Export", subtitle:"Offline • local processing • no account upload") {
                            Button(action: { model.decrypt() }) {
                                HStack(spacing: 8) {
                                    if model.running { ProgressView().tint(.black) }
                                    else { Image(systemName: "lock.open.fill") }
                                    Text(model.running ? "Decrypting…" : "Decrypt IPA")
                                }
                                .font(.headline)
                                .frame(maxWidth:.infinity)
                                .padding(.vertical, 13)
                            }
                            .buttonStyle(.plain)
                            .foregroundStyle(.black)
                            .background(model.credentialAvailable && model.importedIPA != nil && !model.running ? Color.cyan : Color.gray,
                                        in: RoundedRectangle(cornerRadius: 13))
                            .disabled(!model.credentialAvailable || model.importedIPA == nil || model.running)
                            if model.running {
                                ProgressView(value:model.progress).tint(.cyan)
                            }
                            HStack {
                                Text(model.status).font(.caption).foregroundStyle(.secondary)
                                Spacer()
                                if model.running { Text("\(Int(model.progress*100))%").font(.caption).monospacedDigit() }
                            }
                            if let exported = model.outputIPA {
                                Label(model.report, systemImage: "checkmark.circle.fill")
                                    .font(.caption).foregroundStyle(.green)
                                ShareLink(item: exported, preview: SharePreview(exported.lastPathComponent)) {
                                    Label("Save / Share Decrypted IPA", systemImage:"square.and.arrow.up")
                                        .fontWeight(.semibold).frame(maxWidth:.infinity).padding(13)
                                }
                                .background(.green.opacity(0.16), in:RoundedRectangle(cornerRadius:12))
                            }
                        }
                        Text("Research & interoperability use only. The exported IPA is not signed for installation. Use your own license and re-sign separately before installing.")
                            .font(.caption2).foregroundStyle(.secondary).padding(.horizontal, 8)
                    }
                    .padding(20)
                }
            }
            .navigationBarHidden(true)
            .fileImporter(isPresented:$pickingCredential, allowedContentTypes:[.data, .item]) { result in
                switch result {
                case .success(let url): model.importCredential(url)
                case .failure(let error): model.error = error.localizedDescription
                }
            }
            .fileImporter(isPresented:$pickingIPA, allowedContentTypes:[.data, .item]) { result in
                switch result {
                case .success(let url): model.importIPA(url)
                case .failure(let error): model.error = error.localizedDescription
                }
            }
            .alert("RBx9 IPA Decryptor", isPresented: Binding(
                get: { model.error != nil },
                set: { if !$0 { model.error = nil } }
            )) { Button("OK", role:.cancel) { model.error = nil } }
              message: { Text(model.error ?? "Unknown error") }
            .confirmationDialog("Remove credential from this iPhone?", isPresented:$confirmingCredentialRemoval) {
                Button("Remove Credential", role:.destructive) { model.removeCredential() }
                Button("Cancel", role:.cancel) { }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: "lock.open.iphone")
                    .font(.system(size:30, weight:.semibold))
                    .foregroundStyle(.cyan)
                    .frame(width:62,height:62)
                    .background(.cyan.opacity(0.12), in:RoundedRectangle(cornerRadius:18))
                VStack(alignment:.leading,spacing:3) {
                    Text("RBx9 Decryptor").font(.system(size:27,weight:.bold,design:.rounded))
                    Text("Developed by RBx9 • v0.1").font(.caption).foregroundStyle(.secondary)
                }
            }
            Text("FairPlay IPA decryption, entirely on your iPhone.")
                .font(.subheadline).foregroundStyle(.secondary).padding(.top,8)
        }
        .padding(.bottom,8)
    }
}

private struct RBx9ButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.fontWeight(.semibold)
            .frame(maxWidth:.infinity).padding(13)
            .foregroundStyle(.cyan)
            .background(.cyan.opacity(configuration.isPressed ? 0.22 : 0.12), in: RoundedRectangle(cornerRadius: 12))
    }
}
