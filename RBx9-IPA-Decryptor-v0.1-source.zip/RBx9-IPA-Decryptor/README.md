# RBx9 IPA Decryptor · iPhone native prototype v0.1

A standalone SwiftUI iPhone app designed for iOS 16+ (including the intended iOS 27.0.1 target), implementing a **native port** of FairPlay page decryption inspired by [EthanArbuckle/fairplay-decrypt](https://github.com/EthanArbuckle/fairplay-decrypt). Uses `credential.bin` from an Apple account licensed for the IPA; no network service and no jailbreak are needed for the decryption step.

> **Status: source prototype, unverified on-device.** This project has not been compiled with Xcode or run on iOS 27.0.1 in this environment. The native cryptographic port especially needs comparison against real licensed test vectors; please do not rely on the result for anything critical until tested. No prebuilt or signed IPA is included. The public upstream project itself supports Python execution on macOS/Linux, **not** iOS. This is a new port, not a claim that its original code natively runs on iPhone.

## Implemented

- SwiftUI dark/cyan RBx9 interface.
- Files picker for `.ipa` and `credential.bin`.
- 16-byte credential validation and local Keychain storage (`ThisDeviceOnly`, available when unlocked).
- Local ZIP extraction/repacking with ZIPFoundation 0.9.20; Swift + CommonCrypto AES-128 ECB and CBC, CryptoKit MD5.
- SUPF v3/v5, SINF parsing, arm64 / FAT Mach-O parsing, page-key derivation, cryptid clearing and basic post-decrypt checks.
- On-device progress updates, detailed errors, share/export IPA, no-overwrite output names, temporary-file cleanup.
- GitHub Actions workflow for **unsigned** IPA production, intended for signing with your own Apple certificate.

## Build with a Mac

1. Open `RBx9Decryptor.xcodeproj` in Xcode (recent version with iOS SDK; minimum deployment iOS 16.0). Xcode fetches the ZIPFoundation dependency.
2. Choose the `RBx9Decryptor` scheme. In Signing & Capabilities, set your own Apple team and, if necessary, a unique bundle identifier.
3. Build/run on your iPhone with Developer Mode enabled. If using ESign, use the workflow's unsigned IPA and sign it with a valid certificate and provisioning profile.
4. To build unsigned on GitHub, push this folder to your repository, run **Actions → Build unsigned IPA (sign yourself) → Run workflow**, and retrieve the artifact. A successful workflow is not evidence the decryption logic works for your test IPA: test on device.

## Usage

1. Import an **already obtained** `credential.bin` (16 bytes). The app **does not retrieve** it from a device or request an Apple ID password.
2. Import an App Store `.ipa` owned by that account using Files.
3. Choose **Decrypt IPA**. It derives per-page AES keys from SINF/SUPF and processes encrypted arm64 Mach-O slices locally.
4. When successful, use **Save / Share Decrypted IPA** to export the file. Decrypted binaries need **re-signing** to install, and an exported IPA may fail if dependencies or metadata aren't supported.

## Limitations / hardening before release

- iOS 27.0.1 has **not** been validated here. This native approach does not depend on the separate FairPlayed `mremap_encrypted` technique (which requires an embedded target at build time).
- Only upstream-supported FairPlay SINF/SUPF types and encrypted arm64 Mach-O slices. Other formats are rejected.
- Extracted IPAs can use several times their archive size temporarily; ensure adequate free disk space.
- ZIPFoundation is fetched from GitHub by Xcode on first build; the **app itself** makes no network requests.
- For untrusted ZIP files, consider stricter limits on decompressed size and entry count, and check all nested Mach-O binaries, even without a corresponding SUPF. The current implementation examines listed SUPF binaries; it is not a formal certification that *every* binary in the IPA has been decrypted.
- Credentials are highly sensitive; don't send them to others or commit them into source control. If your Apple account credential does not match the IPA, decryption fails.
- Review third-party software rights and Apple agreements; use for apps you have a license for and legitimate research/interoperability.

## License and attribution

GPL-3.0-only; the native decryption logic is a derivative port of EthanArbuckle's GPL-3.0-licensed project. Preserve notices and provide corresponding source to recipients when distributing binaries. ZIPFoundation is MIT licensed (fetched separately by Xcode).

## Headless regression test (Linux development environment)

`Tests/run-linux-headless.sh` generates a synthetic, authorized one-page Mach-O FairPlay fixture in Python, then compiles the same native Swift decryption core under Linux with an OpenSSL test shim standing in for Apple CommonCrypto/CryptoKit. It compares the decrypted bytes with the Python reference, including `cryptid=0`. This verifies algorithm behavior for **one synthetic format**, not real IPA coverage or iOS compilation.

Run it on Linux with `swiftc`, `clang`, OpenSSL development headers, and Python `cryptography` installed.
