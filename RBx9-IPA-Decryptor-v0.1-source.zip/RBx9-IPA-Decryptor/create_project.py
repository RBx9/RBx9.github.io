#!/usr/bin/env python3
"""Regenerate a standalone Xcode project without xcodegen."""
from pathlib import Path
root=Path(__file__).resolve().parent
proj=root/'RBx9Decryptor.xcodeproj'
proj.mkdir(exist_ok=True)
names=['RBx9App.swift','ContentView.swift','AppModel.swift','CredentialVault.swift','IPADecryptService.swift','FairPlayCore.swift']

def oid(i): return f'BAA91B00{i:016X}'
# ids 1-... generated as 24 hexadecimal chars.
project, target, maingroup, sourcegroup, productgroup = [oid(i) for i in range(1,6)]
sources, frameworks, resources = [oid(i) for i in range(6,9)]
productref,plistref,package,dep = [oid(i) for i in range(9,13)]
pcfglist, tcfglist, pdebug, prelease, tdebug, trelease = [oid(i) for i in range(13,19)]
files = [oid(i) for i in range(30,36)]
builds = [oid(i) for i in range(40,46)]
packagebuild=oid(50)
objects={}

def put(id, body): objects[id]=body
put(project, f'''isa = PBXProject; attributes = {{ LastUpgradeCheck = 1600; TargetAttributes = {{ {target} = {{ CreatedOnToolsVersion = 16.0; }}; }}; }}; buildConfigurationList = {pcfglist}; compatibilityVersion = "Xcode 15.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en, Base); mainGroup = {maingroup}; packageReferences = ({package}); productRefGroup = {productgroup}; projectDirPath = ""; projectRoot = ""; targets = ({target});''')
put(target, f'''isa = PBXNativeTarget; buildConfigurationList = {tcfglist}; buildPhases = ({sources}, {frameworks}, {resources}); buildRules = (); dependencies = (); name = RBx9Decryptor; packageProductDependencies = ({dep}); productName = RBx9Decryptor; productReference = {productref}; productType = "com.apple.product-type.application";''')
put(maingroup,f'''isa = PBXGroup; children = ({sourcegroup}, {productgroup}); sourceTree = "<group>";''')
put(sourcegroup,'''isa = PBXGroup; children = ('''+', '.join(files+[plistref])+'''); name = RBx9Decryptor; path = RBx9Decryptor; sourceTree = "<group>";''')
put(productgroup,f'''isa = PBXGroup; children = ({productref}); name = Products; sourceTree = "<group>";''')
put(sources, '''isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ('''+', '.join(builds)+'''); runOnlyForDeploymentPostprocessing = 0;''')
put(frameworks,f'''isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = ({packagebuild}); runOnlyForDeploymentPostprocessing = 0;''')
put(resources,'''isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;''')
put(productref,'''isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = RBx9Decryptor.app; sourceTree = BUILT_PRODUCTS_DIR;''')
put(plistref,'''isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = Info.plist; sourceTree = "<group>";''')
for name,fileid,buildid in zip(names,files,builds):
    put(fileid,f'''isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {name}; sourceTree = "<group>";''')
    put(buildid,f'''isa = PBXBuildFile; fileRef = {fileid};''')
put(packagebuild,f'''isa = PBXBuildFile; productRef = {dep};''')
put(package,'''isa = XCRemoteSwiftPackageReference; repositoryURL = "https://github.com/weichsel/ZIPFoundation.git"; requirement = { kind = upToNextMajorVersion; minimumVersion = 0.9.20; };''')
put(dep,f'''isa = XCSwiftPackageProductDependency; package = {package}; productName = ZIPFoundation;''')
put(pcfglist,f'''isa = XCConfigurationList; buildConfigurations = ({pdebug}, {prelease}); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;''')
put(tcfglist,f'''isa = XCConfigurationList; buildConfigurations = ({tdebug}, {trelease}); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;''')
base='''ALWAYS_SEARCH_USER_PATHS = NO; CLANG_ENABLE_MODULES = YES; SDKROOT = iphoneos; IPHONEOS_DEPLOYMENT_TARGET = 16.0; TARGETED_DEVICE_FAMILY = 1; SWIFT_VERSION = 5.0;'''
for id,name,extra in [(pdebug,'Debug','DEBUG_INFORMATION_FORMAT = dwarf; SWIFT_OPTIMIZATION_LEVEL = "-Onone";'),(prelease,'Release','DEBUG_INFORMATION_FORMAT = "dwarf-with-dsym"; SWIFT_COMPILATION_MODE = wholemodule;'),]:
    put(id,f'''isa = XCBuildConfiguration; buildSettings = {{ {base} {extra} }}; name = {name};''')
targetsettings='''ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS = NO; CODE_SIGN_STYLE = Automatic; CURRENT_PROJECT_VERSION = 1; GENERATE_INFOPLIST_FILE = NO; INFOPLIST_FILE = RBx9Decryptor/Info.plist; MARKETING_VERSION = 0.1.0; PRODUCT_BUNDLE_IDENTIFIER = com.rbx9.ipadecryptor; PRODUCT_NAME = "$(TARGET_NAME)"; SWIFT_VERSION = 5.0; IPHONEOS_DEPLOYMENT_TARGET = 16.0; TARGETED_DEVICE_FAMILY = 1; SUPPORTS_MACCATALYST = NO;'''
for id,name,extra in [(tdebug,'Debug','SWIFT_ACTIVE_COMPILATION_CONDITIONS = DEBUG; SWIFT_OPTIMIZATION_LEVEL = "-Onone";'),(trelease,'Release','SWIFT_COMPILATION_MODE = wholemodule;')]:
    put(id,f'''isa = XCBuildConfiguration; buildSettings = {{ {targetsettings} {extra} }}; name = {name};''')
header='''// !$*UTF8*$!\n{\n archiveVersion = 1;\n classes = {};\n objectVersion = 60;\n objects = {\n'''
project_text = header + ''.join(f'  {id} = {{ {body} }};\n' for id,body in objects.items()) + f''' }};\n rootObject = {project};\n}}\n'''
(proj/'project.pbxproj').write_text(project_text)
schemedir=proj/'xcshareddata/xcschemes'
schemedir.mkdir(parents=True,exist_ok=True)
(schemedir/'RBx9Decryptor.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES">
    <BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="RBx9Decryptor.app" BlueprintName="RBx9Decryptor" ReferencedContainer="container:RBx9Decryptor.xcodeproj"/></BuildActionEntry></BuildActionEntries>
  </BuildAction>
  <LaunchAction buildConfiguration="Debug"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="RBx9Decryptor.app" BlueprintName="RBx9Decryptor" ReferencedContainer="container:RBx9Decryptor.xcodeproj"/></BuildableProductRunnable></LaunchAction>
  <ProfileAction buildConfiguration="Release"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="RBx9Decryptor.app" BlueprintName="RBx9Decryptor" ReferencedContainer="container:RBx9Decryptor.xcodeproj"/></BuildableProductRunnable></ProfileAction>
  <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES" />
</Scheme>''')
print('Wrote',proj/'project.pbxproj')
